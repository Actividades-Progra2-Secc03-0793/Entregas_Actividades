﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_4_Lambda_MVC
{
    /*-->
        2. Programa que permita calcular el valor final a pagar en una 
        súper tienda en
        donde se aplican los siguientes descuentos:
            a) Por compras entre 10000 y 20000 el 10%
            b) Por compras entre 20001 y 50000 el 30%
            c) Por compras superiores a 50000 el 50%
            Utilizar Lambda para su desarrollo
        <--*/

    // Definicion del delegado de SUPER TIENDA
    public delegate double Compra(double valor_compra);

    class Super_Tienda
    {
        
        // Método que retornara el valor final a pagar en la super tienda
        public double Valor_Paga(double valor_compra)
        {
            double total_a_pagar = 0, descuento = 0;

            // Comprobar que el dato sea positivo
            if (valor_compra >= 0)
            {
                // Aplicando condicion para ver si hay descuento que aplicar
                if (valor_compra >= 10000 && valor_compra <= 20000)
                {
                    descuento = valor_compra * .10;
                }
                else if (valor_compra >= 20001 && valor_compra <= 50000)
                {
                    descuento = valor_compra * .30;
                }
                else if (valor_compra > 50000)
                {
                    descuento = valor_compra * .50;
                }
                else
                {
                    descuento = 0;
                }
            }
            else
            {
                Console.WriteLine("El valor de la compra debe ser positivo\n");
                valor_compra = 0;
            }

            // Aplcicando el descuento
            total_a_pagar = valor_compra - descuento;
            // Devolviendo el valor final
            return total_a_pagar;
        }
    }
}
