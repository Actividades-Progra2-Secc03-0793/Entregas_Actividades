﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Parcial_4_Ejercicio4.Models;

namespace Parcial_4_Ejercicio4.Controllers
{
    public class PromedioEstController : Controller
    {
        // GET: PromedioEst
        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult Promedio()
        {
            Promedio_Estudiante obPE = new Promedio_Estudiante();
            string prom = Request.Params["btnEnviar"];
            obPE.codEstudiante = Request.Form["txtCod"];
            obPE.nomEstudiante = Request.Form["txtNom"];
            obPE.nomMateria = Request.Form["txtMat"];
            obPE.nota1 = double.Parse(Request.Form["txtNot1"].ToString());
            obPE.nota2 = double.Parse(Request.Form["txtNot2"].ToString());
            obPE.nota3 = double.Parse(Request.Form["txtNot3"].ToString());

            obPE.Promedio = (obPE.nota1 + obPE.nota2 + obPE.nota3) / 3;

            if (obPE.Promedio > 4.0)
                obPE.Resultado = "Aprobado";
            else
                obPE.Resultado = "Reprobado";

            return View("Promedio", obPE);
        }
    }
}