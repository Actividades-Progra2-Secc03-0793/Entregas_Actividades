﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_4_Lambda_MVC
{
    class Program
    {
        /*-->
        2. Programa que permita calcular el valor final a pagar en una 
        súper tienda en
        donde se aplican los siguientes descuentos:
            a) Por compras entre 10000 y 20000 el 10%
            b) Por compras entre 20001 y 50000 el 30%
            c) Por compras superiores a 50000 el 50%
            Utilizar Lambda para su desarrollo
        <--*/
        static void Main(string[] args)
        {
            Super_Tienda st = new Super_Tienda();

            Console.WriteLine("----------------------------------BIENVENIDO A SUPER TIENDA----------------------------------\n");
            Console.WriteLine("Articulos del Usuario");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("1. Laptop HP Intel Core ¡3");
            Console.WriteLine("2. Mouse HP");
            Console.WriteLine("3. Teclado HP");
            Console.WriteLine("-----------------------------------\n");
            Console.Write("> Ingrece el total de la compra : $");
            double compra = Convert.ToDouble(Console.ReadLine());

            Compra getCompra = st.Valor_Paga;
            Console.WriteLine("\nDescuento que se aplicara");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine(" Por compras entre 10000 y 20000 el 10%");
            Console.WriteLine(" Por compras entre 20001 y 50000 el 30%");
            Console.WriteLine(" Por compras superiores a 50000 el 50%");
            Console.WriteLine("-----------------------------------\n");
            Console.WriteLine("El total a pagar será de: ${0}", getCompra(compra));
            Console.WriteLine("\n> Precione cualquier tecla para salir del programa...");
            Console.ReadKey();

        }
    }
}
