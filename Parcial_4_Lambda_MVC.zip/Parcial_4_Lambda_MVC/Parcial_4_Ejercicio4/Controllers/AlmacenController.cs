﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Parcial_4_Ejercicio4.Models;

namespace Parcial_4_Ejercicio4.Controllers
{
    public class AlmacenController : Controller
    {
        // GET: Almacen
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Compra()
        {
            Almacen obAlmace = new Almacen();
            string comp = Request.Params["btnEnviar"];
            obAlmace.stock1 = int.Parse(Request.Form["txtStrock1"].ToString());
            obAlmace.stock2 = int.Parse(Request.Form["txtStrock2"].ToString());
            obAlmace.stock3 = int.Parse(Request.Form["txtStrock3"].ToString());
            obAlmace.stock4 = int.Parse(Request.Form["txtStrock4"].ToString());
            obAlmace.stock5 = int.Parse(Request.Form["txtStrock5"].ToString());

            double subtotal1 = obAlmace.stock1 * 750.00, subtotal2 = obAlmace.stock2 * 1250.00, subtotal3 = obAlmace.stock3 * 50.00;
            double subtotal4 = obAlmace.stock4 * 99.00, subtotal5 = obAlmace.stock5 * 350.00;

            obAlmace.Total = subtotal1 + subtotal2 + subtotal3 + subtotal4 + subtotal5;

            if (obAlmace.Total > 100000)
            {
                double descuento = obAlmace.Total * .2;
                obAlmace.Total = obAlmace.Total - descuento;
                obAlmace.descuento = " fue Aplicado";
            }
            else
                obAlmace.descuento = "No fue aplicado";



            return View("Compra", obAlmace);
        }

    }
}