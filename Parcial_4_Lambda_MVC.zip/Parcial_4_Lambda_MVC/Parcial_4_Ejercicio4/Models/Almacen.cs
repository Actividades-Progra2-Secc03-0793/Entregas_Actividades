﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial_4_Ejercicio4.Models
{
    public class Almacen
    {
        public int stock1 { get; set; }
        public int stock2 { get; set; }
        public int stock3 { get; set; }
        public int stock4 { get; set; }
        public int stock5 { get; set; }
        public double Total { get; set; }
        public string descuento { get; set; }

    }
}