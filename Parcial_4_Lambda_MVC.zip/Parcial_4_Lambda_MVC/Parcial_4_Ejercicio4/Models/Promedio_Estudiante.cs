﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial_4_Ejercicio4.Models
{
    public class Promedio_Estudiante
    {
        public string codEstudiante { get; set; }
        public string nomEstudiante { get; set; }
        public string nomMateria { get; set; }
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
        public double Promedio { get; set; }

        public string Resultado { get; set; }
    }
}